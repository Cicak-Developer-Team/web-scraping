<table>
    <thead>
        <tr>
            <th>NO</th>
            <th>JUDUL</th>
            <th>LINK</th>
            <th>SUB</th>
            <th>ARTIKEL</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($item['title']); ?></td>
                <td><?php echo e($item['link']); ?></td>
                <td><?php echo e($item['sub']); ?></td>
                <td><?php echo e($item['artikel']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\Web\Kerja\FutureProjectCDT\web-scraping\resources\views/printHasil.blade.php ENDPATH**/ ?>